# CS373_2023_Assignment_Barcode_Detection
## Name: Helen Lu, UPI: hlu750

This is my image processing assignment for CompSci 373 in Semester 1, 2023.  This assignment requires me to use what we have studied in the image processing lectures to generate a software that detects barcodes in images of household items.  

My solution for the solving the barcode detection problem can be found in CS373_barcode_detection.py.
My additional component, where I extend upon the barcode detection in a separate file, can be found in CS373_extension.py.
I have written a short reflective report about my extension in Extension_Report.md.
